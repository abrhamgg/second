from tkinter import*
import math
root = Tk()
root.geometry("1100x500")
root.title("area of trapezoid")

def Area():
    b1 = float(entry.get())
    b2 = float(entry1.get())
    h = float(entry2.get())
    A = h/2*(b1 + b2)
    output_label.configure(text="Area of Traezium is {}".format(A))

label = Label(text="Enter a length of base one(b1)",font="liberation 15")
label.grid(row=0,column=0)

entry=Entry()
entry.grid(row=0, column=1)

label1 = Label(text="Enter a length of base two(b2)",font="liberation 15")
label1.grid(row=1,column=0)

entry1=Entry()
entry1.grid(row=1, column=1)

label2 = Label(text="Enter height of trapezium(h)",font="liberation 15")
label2.grid(row=2,column=0)

entry2=Entry()
entry2.grid(row=2, column=1)

button = Button(text= "Evaluate",font="liberation 15",command=Area)
button.grid(row=0,column=2)


output_label = Label(font="liberation 15")
output_label.grid(row=0, column=3)

root.mainloop()