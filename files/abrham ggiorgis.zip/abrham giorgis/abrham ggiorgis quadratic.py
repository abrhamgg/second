from tkinter import*
import math
root = Tk()
root.geometry("1100x500")
root.title("quadratic function")

def quadratic():
    a = float(entry.get())
    b = float(entry1.get())
    c = float(entry2.get())
    v = float(pow(b,2)-4*a*c)
    w = "null"





    if v >= 0:
        o = float((-b + (pow(v, 0.5))))
        n = float((-b - (pow(v, 0.5))))
        x1 = float(o / (2 * a))
        x2 = float(n / (2 * a))

        output_label_x1.configure(text="x1 is equal to{}".format(x1))
        output_label1_x2.configure(text="x2 is equal to{}".format(x2))
        
    elif v < 0:
        output_label_x1.configure(text=f"x1 is {w} ")
        output_label1_x2.configure(text=f"x2 is{w}")


label = Label(text="Enter value of a",font="liberation 15")
label.grid(row=0,column=0)

entry=Entry()
entry.grid(row=0, column=1)

label1 = Label(text="Enter value of b",font="liberation 15")
label1.grid(row=1,column=0)

entry1=Entry()
entry1.grid(row=1, column=1)

label2 = Label(text="enter value of c",font="liberation 15")
label2.grid(row=2,column=0)

entry2=Entry()
entry2.grid(row=2, column=1)

button = Button(text= "Evaluate",font="liberation 15",command=quadratic)
button.grid(row=0,column=2)

output_label_x1 = Label(font="liberation 15")
output_label_x1.grid(row=0, column=3)

output_label1_x2 = Label(font="liberation 15")
output_label1_x2.grid(row=1, column=3)

output_label3 = Label(font="liberation 15")
output_label3.grid(row=2, column=3)



root.mainloop()